

<?php
//connessione al server 
    $con = mysqli_connect('localhost','root','','nunzistore') or die('connessione non riuscita!');
?>